package app.glassnotify

import android.Manifest
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.util.TypedValue
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var statusAccess: TextView
    private lateinit var statusOverlay: TextView
    private lateinit var statusCapture: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = Prefs.of(this)
        val pad = dp(20)

        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, dp(32), pad, pad)
        }

        fun text(value: String, sp: Float, bold: Boolean = false, top: Int = 0) = TextView(this).apply {
            this.text = value
            setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(top), 0, 0)
        }

        fun button(label: String, onClick: () -> Unit) = Button(this).apply {
            this.text = label
            setOnClickListener { onClick() }
        }

        column.addView(text("Glass Notify", 28f, bold = true))
        column.addView(
            text(
                "Пузырёк уведомлений сверху экрана в стиле liquid glass, шейдер и анимация с сайта. " +
                    "Выдай разрешения ниже. Смахни плашку вверх, чтобы убрать, или нажми, чтобы открыть приложение.",
                15f, top = 8
            )
        )

        statusAccess = text("", 15f, bold = true, top = 24)
        column.addView(statusAccess)
        column.addView(button("Доступ к уведомлениям") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })

        statusOverlay = text("", 15f, bold = true, top = 16)
        column.addView(statusOverlay)
        column.addView(button("Поверх других окон") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })

        statusCapture = text("", 15f, bold = true, top = 16)
        column.addView(statusCapture)
        column.addView(
            text(
                "Преломление фона как на сайте требует снимка экрана. В системном окне выбери «Весь экран». " +
                    "Экран снимается только когда приходит уведомление и ещё пару секунд после. " +
                    "Но значок записи Android может висеть всё время, пока это включено.",
                13f
            )
        )
        column.addView(button("Включить преломление фона") {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 3)
            }
            val mpm = getSystemService(MediaProjectionManager::class.java)
            startActivityForResult(mpm.createScreenCaptureIntent(), 2)
        })
        column.addView(button("Выключить преломление") {
            stopService(Intent(this, CaptureService::class.java))
            statusCapture.postDelayed({ refresh() }, 300)
        })

        column.addView(text("Настройки", 15f, bold = true, top = 24))

        val enabled = Switch(this).apply {
            text = "Показывать пузырёк"
            isChecked = prefs.getBoolean(Prefs.ENABLED, true)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(Prefs.ENABLED, checked).apply() }
            setPadding(0, dp(8), 0, dp(8))
        }
        column.addView(enabled)

        val hide = Switch(this).apply {
            text = "Убирать оригинальное уведомление из шторки"
            isChecked = prefs.getBoolean(Prefs.HIDE_ORIGINAL, false)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(Prefs.HIDE_ORIGINAL, checked).apply() }
            setPadding(0, dp(8), 0, dp(8))
        }
        column.addView(hide)

        column.addView(button("Показать тестовое уведомление") { sendTest() })

        column.addView(
            text(
                "Если «Доступ к уведомлениям» серый и не нажимается: открой «О приложении», " +
                    "нажми ⋮ в правом верхнем углу и выбери «Разрешить ограниченные настройки». " +
                    "Так Android 13+ блокирует приложения, установленные не из магазина.",
                13f, top = 24
            )
        )
        column.addView(button("Открыть «О приложении»") {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            )
        })

        column.addView(
            text(
                "Чтобы приложение не выгружалось системой: Настройки → Приложения → Glass Notify → " +
                    "Батарея → «Без ограничений».",
                13f, top = 16
            )
        )

        setContentView(ScrollView(this).apply { addView(column) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val access = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(packageName) == true
        val overlay = Settings.canDrawOverlays(this)
        statusAccess.text = if (access) "✓ Доступ к уведомлениям выдан" else "✗ Нет доступа к уведомлениям"
        statusOverlay.text = if (overlay) "✓ Показ поверх окон разрешён" else "✗ Показ поверх окон не разрешён"
        statusCapture.text =
            if (Capture.active) "✓ Преломление включено (снимает экран только при уведомлениях)" else "✗ Преломление выключено (будет тёмное стекло)"
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2 && resultCode == RESULT_OK && data != null) {
            val svc = Intent(this, CaptureService::class.java)
                .putExtra("code", resultCode)
                .putExtra("data", data)
            startForegroundService(svc)
            statusCapture.postDelayed({ refresh() }, 800)
        }
    }

    private fun sendTest() {
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            return
        }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("test", "Тест", NotificationManager.IMPORTANCE_HIGH)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "test")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Анна")
            .setContentText("Ты где? Мы уже внизу")
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(1, n)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            sendTest()
        }
    }
}
