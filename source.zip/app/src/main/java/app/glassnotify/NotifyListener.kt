package app.glassnotify

import android.app.Notification
import android.app.NotificationManager
import android.content.Context
import android.graphics.drawable.Drawable
import android.os.PowerManager
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.NotificationListenerService.Ranking
import android.service.notification.NotificationListenerService.RankingMap
import android.service.notification.StatusBarNotification

class NotifyListener : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification, rankingMap: RankingMap) {
        val prefs = Prefs.of(this)
        if (!prefs.getBoolean(Prefs.ENABLED, true)) return
        if (!Settings.canDrawOverlays(this)) return

        val n = sbn.notification ?: return

        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return
        when (n.category) {
            Notification.CATEGORY_TRANSPORT,
            Notification.CATEGORY_PROGRESS,
            Notification.CATEGORY_SERVICE,
            Notification.CATEGORY_SYSTEM,
            Notification.CATEGORY_STATUS -> return
        }

        val ranking = Ranking()
        if (rankingMap.getRanking(sbn.key, ranking) &&
            ranking.importance < NotificationManager.IMPORTANCE_DEFAULT
        ) return

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!pm.isInteractive) return

        val extras = n.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return

        val pkg = sbn.packageName
        val appName = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }

        val avatar: Drawable? = try {
            n.getLargeIcon()?.loadDrawable(this)
        } catch (e: Exception) {
            null
        }
        val appIcon: Drawable? = try {
            packageManager.getApplicationIcon(pkg)
        } catch (e: Exception) {
            null
        }
        val icon: Drawable? = avatar ?: appIcon

        val intent = n.contentIntent
        // Сначала включаем съёмку экрана, баннер покажется, когда будет свежий кадр.
        Capture.begin {
            GlassBanner.show(
                ctx = this,
                appName = appName,
                title = title,
                text = text,
                icon = icon,
                contentIntent = intent,
                durationMs = Config.HOLD_MS
            )
        }

        if (prefs.getBoolean(Prefs.HIDE_ORIGINAL, false)) {
            cancelNotification(sbn.key)
        }
    }
}
