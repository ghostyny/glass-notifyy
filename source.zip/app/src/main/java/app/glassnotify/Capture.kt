package app.glassnotify

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.view.Surface
import android.view.WindowManager
import kotlin.math.min

/**
 * Состояние записи экрана. Сессия MediaProjection живёт, пока включён сервис, но реально кадры
 * снимаются только когда приходит уведомление и ещё STOP_DELAY_MS после закрытия баннера:
 * в остальное время поверхность VirtualDisplay отключена (setSurface(null)), расхода почти нет.
 */
object Capture {
    @Volatile var strip: Bitmap? = null
    /** Пока баннер на экране, новые кадры не сохраняем, чтобы в снимок не попал он сам. */
    @Volatile var paused = false
    /** Сессия MediaProjection выдана и жива. */
    @Volatile var active = false
    /** Поверхность подключена, кадры идут. */
    @Volatile var running = false
    @Volatile var width = 0
    @Volatile var stripH = 0
    @Volatile var lastT = 0L
    var display: VirtualDisplay? = null
    var surface: Surface? = null

    private val main = Handler(Looper.getMainLooper())
    private var pending: (() -> Unit)? = null
    private val stopRun = Runnable { stop() }
    private val timeoutRun = Runnable { fire() }

    /** Включает съёмку и вызывает cb, когда есть свежий кадр (или через 400 мс без него). */
    fun begin(cb: () -> Unit) {
        main.post {
            if (!active) {
                cb()
            } else {
                main.removeCallbacks(stopRun)
                if (running && strip != null) {
                    cb()
                } else {
                    pending = cb
                    main.removeCallbacks(timeoutRun)
                    if (!running) {
                        strip = null
                        lastT = 0L
                        paused = false
                        display?.surface = surface
                        running = true
                    }
                    main.postDelayed(timeoutRun, 400)
                }
            }
        }
    }

    private fun fire() {
        main.removeCallbacks(timeoutRun)
        val c = pending
        pending = null
        c?.invoke()
    }

    /** Вызывается из потока записи, когда сохранён новый кадр. */
    fun frameStored() {
        if (pending != null) main.post { fire() }
    }

    fun holdOn() {
        main.removeCallbacks(stopRun)
    }

    fun schedulePause(delayMs: Long) {
        main.removeCallbacks(stopRun)
        main.postDelayed(stopRun, delayMs)
    }

    fun stop() {
        if (!running) return
        running = false
        strip = null
        display?.surface = null
    }

    fun reset() {
        main.removeCallbacks(stopRun)
        main.removeCallbacks(timeoutRun)
        pending = null
        running = false
        active = false
        strip = null
        display = null
        surface = null
    }
}

class CaptureService : Service() {

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getIntExtra("code", 0) ?: 0
        val data: Intent? = intent?.getParcelableExtra("data", Intent::class.java)
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        startAsForeground()
        try {
            startCapture(code, data)
        } catch (e: Exception) {
            Capture.reset()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("capture", "Преломление фона", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "capture")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("Glass Notify")
            .setContentText("Преломление включено, экран снимается только при уведомлениях")
            .setOngoing(true)
            .build()
        startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    private fun startCapture(code: Int, data: Intent) {
        val th = HandlerThread("glass-capture")
        th.start()
        thread = th
        val handler = Handler(th.looper)

        val mpm = getSystemService(MediaProjectionManager::class.java)
        val mp = mpm.getMediaProjection(code, data)
        projection = mp
        // Android 14+: колбэк нужно зарегистрировать до createVirtualDisplay.
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                Capture.reset()
                stopSelf()
            }
        }, handler)

        val bounds = getSystemService(WindowManager::class.java).maximumWindowMetrics.bounds
        val w = bounds.width()
        val h = bounds.height()
        val density = resources.displayMetrics.density
        Capture.width = w
        Capture.stripH = min(h, (240 * density).toInt())

        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        reader = r
        r.setOnImageAvailableListener({ rd -> onImage(rd) }, handler)
        val vd = mp.createVirtualDisplay(
            "glass-notify", w, h, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
        )
        display = vd
        Capture.display = vd
        Capture.surface = r.surface
        // Сразу на паузу: кадры нужны только во время уведомлений.
        vd.surface = null
        Capture.running = false
        Capture.active = true
    }

    private fun onImage(rd: ImageReader) {
        val img = try {
            rd.acquireLatestImage()
        } catch (e: Exception) {
            null
        } ?: return
        try {
            if (Capture.paused || !Capture.running) return
            val now = SystemClock.uptimeMillis()
            if (now - Capture.lastT < 100) return
            Capture.lastT = now
            val plane = img.planes[0]
            val rowPx = plane.rowStride / plane.pixelStride
            val sh = Capture.stripH
            val tmp = Bitmap.createBitmap(rowPx, sh, Bitmap.Config.ARGB_8888)
            val buf = plane.buffer
            buf.rewind()
            tmp.copyPixelsFromBuffer(buf)
            Capture.strip =
                if (rowPx == Capture.width) tmp
                else Bitmap.createBitmap(tmp, 0, 0, Capture.width, sh)
            Capture.frameStored()
        } catch (e: Exception) {
            // пропускаем кадр
        } finally {
            img.close()
        }
    }

    override fun onDestroy() {
        Capture.reset()
        runCatching { display?.release() }
        runCatching { reader?.close() }
        runCatching { projection?.stop() }
        runCatching { thread?.quitSafely() }
        super.onDestroy()
    }
}
