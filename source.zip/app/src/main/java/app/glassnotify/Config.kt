package app.glassnotify

// Этот файл перезаписывается воркфлоу из параметров запуска (Actions → Run workflow).
object Config {
    const val HOLD_MS = 3200L
    const val STOP_DELAY_MS = 2000L
}
