package app.glassnotify

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RuntimeShader
import android.graphics.Shader
import android.view.View

/**
 * Порт шейдера с сайта «Liquid Glass: капля» на AGSL, без изменений в математике:
 * скруглённый прямоугольник, слияние с «островом» через smin, волна при движении,
 * преломление картинки под плашкой (6 проб, хроматическая аберрация), блик, кромка и фаска.
 * Картинка под плашкой (uTex) — снимок верхней полосы экрана из CaptureService.
 * Если снимка нет, рисуется тёмное стекло с теми же бликами.
 */
class GlassView(context: Context) : View(context) {

    private val shader = RuntimeShader(AGSL)
    private val paint = Paint()
    private val dummy = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)

    private var rect = floatArrayOf(0f, 0f, 1f, 1f)
    private var pill = floatArrayOf(0f, 0f, 1f, 1f)
    private var glassAlpha = 0f
    private var ab = 0.3f
    private var rad = 1f
    private var dpr = 1f
    private var wob = 0f
    private var time = 0f
    private var pillOn = 0f
    private var hasTex = 0f
    private var ox = 0f
    private var oy = 0f
    private var gw = 1f
    private var gh = 1f

    init {
        paint.shader = shader
        setTexture(null)
    }

    fun setTexture(bm: Bitmap?) {
        hasTex = if (bm != null) 1f else 0f
        shader.setInputShader(
            "uTex",
            BitmapShader(bm ?: dummy, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        )
    }

    /** Окно с шейдером сидит вокруг плашки и двигается; ox, oy — его угол на экране, gw, gh — размер полосы-снимка. */
    fun setFrame(ox: Float, oy: Float, gw: Float, gh: Float) {
        this.ox = ox
        this.oy = oy
        this.gw = gw
        this.gh = gh
    }

    fun update(
        cx: Float, cy: Float, hw: Float, hh: Float,
        pcx: Float, pcy: Float, phw: Float, phh: Float,
        alpha: Float, ab: Float, rad: Float, dpr: Float, wob: Float, time: Float, pillOn: Float
    ) {
        rect = floatArrayOf(cx, cy, hw, hh)
        pill = floatArrayOf(pcx, pcy, phw, phh)
        this.glassAlpha = alpha
        this.ab = ab
        this.rad = rad
        this.dpr = dpr
        this.wob = wob
        this.time = time
        this.pillOn = pillOn
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        shader.setFloatUniform("uSize", gw, gh)
        shader.setFloatUniform("uOrigin", ox, oy)
        shader.setFloatUniform("uRect", rect[0], rect[1], rect[2], rect[3])
        shader.setFloatUniform("uPill", pill[0], pill[1], pill[2], pill[3])
        shader.setFloatUniform("uAlpha", glassAlpha)
        shader.setFloatUniform("uAb", ab)
        shader.setFloatUniform("uRad", rad)
        shader.setFloatUniform("uDpr", dpr)
        shader.setFloatUniform("uWob", wob)
        shader.setFloatUniform("uTime", time)
        shader.setFloatUniform("uHasTex", hasTex)
        shader.setFloatUniform("uPillOn", pillOn)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
    }

    companion object {
        private val AGSL = """
            uniform shader uTex;
            uniform float2 uSize;
            uniform float2 uOrigin;
            uniform float4 uRect;
            uniform float4 uPill;
            uniform float uAlpha;
            uniform float uAb;
            uniform float uRad;
            uniform float uDpr;
            uniform float uWob;
            uniform float uTime;
            uniform float uHasTex;
            uniform float uPillOn;

            float3 tp(float2 p) {
                return float3(uTex.eval(clamp(p, float2(0.5), uSize - float2(0.5))).rgb);
            }

            float sdR(float2 p, float2 c, float2 hb, float r) {
                float2 q = abs(p - c) - (hb - float2(r));
                return length(max(q, float2(0.0))) + min(max(q.x, q.y), 0.0) - r;
            }

            float smin2(float a, float b, float k) {
                float h = max(k - abs(a - b), 0.0) / k;
                return min(a, b) - h * h * k * 0.25;
            }

            float field(float2 p, float gNear, float r) {
                float dB = sdR(p, uRect.xy, uRect.zw, r);
                float dP = sdR(p, uPill.xy, uPill.zw, uPill.w);
                float d = mix(dB, smin2(dB, dP, 26.0 * uDpr), gNear);
                return d + uWob * sin(p.x * 0.05 + uTime * 11.0) * sin(p.y * 0.06 + uTime * 8.0);
            }

            half4 main(float2 fc) {
                float2 p = fc + uOrigin;
                float r = max(min(uRad, min(uRect.z, uRect.w)), 1.0);
                float gNear = uPillOn * (1.0 - smoothstep(0.0, 40.0 * uDpr,
                    sdR(uPill.xy, uRect.xy, uRect.zw, r)));
                float d = field(p, gNear, r);
                float ins = 1.0 - smoothstep(-1.0, 0.75, d);
                if (ins <= 0.0 || uAlpha < 0.001) {
                    return half4(0.0);
                }
                float e = uDpr;
                float2 n = normalize(float2(
                    field(p + float2(e, 0.0), gNear, r) - field(p - float2(e, 0.0), gNear, r),
                    field(p + float2(0.0, e), gNear, r) - field(p - float2(0.0, e), gNear, r)
                ) + float2(0.0001));
                float depth = clamp(-d / r, 0.0, 1.0);
                float edge = pow(1.0 - depth, 2.2);
                float2 dir = p - uRect.xy;

                float2 L = normalize(float2(-0.6, -0.8));
                float lit = pow(max(dot(n, L), 0.0), 2.0) + 0.6 * pow(max(dot(n, -L), 0.0), 2.0);
                float band = 1.0 - smoothstep(0.0, 0.25, depth);
                float hair = 1.0 - smoothstep(0.0, 1.8 * uDpr, -d);
                float topv = smoothstep(0.0, 1.0,
                    1.0 - (p.y - (uRect.y - uRect.w)) / max(2.0 * uRect.w, 1.0)) * 0.10;
                float g = (0.45 * band * band * lit + 0.38 * hair) * 1.2 + topv * 1.2;

                float3 col = float3(0.0);
                float a = 1.0;
                if (uHasTex > 0.5) {
                    float2 c0 = uRect.xy + dir / 1.06;
                    float k = edge * 1.2 * 28.0 * uDpr;
                    float abv = uAb * 0.35;
                    float br = 6.0 * uDpr;
                    for (int i = 0; i < 6; i++) {
                        float an = float(i) * 1.0472;
                        float2 o = float2(cos(an), sin(an)) * br;
                        col += float3(
                            tp(c0 + n * k * (1.0 + abv) + o).r,
                            tp(c0 + n * k + o).g,
                            tp(c0 + n * k * (1.0 - abv) + o).b);
                    }
                    col = col / 6.0 * 0.74 + float3(0.05);
                } else {
                    col = float3(0.13, 0.14, 0.18);
                    a = 0.5;
                }

                float pm = gNear * (1.0 - smoothstep(-2.0 * uDpr, 2.0 * uDpr,
                    sdR(p, uPill.xy, uPill.zw, uPill.w)));
                col = mix(col, float3(0.0), pm);
                a = mix(a, 1.0, pm);

                col = clamp(col + float3(g), 0.0, 1.0);
                float aF = clamp(a + g, 0.0, 1.0);
                float o2 = ins * uAlpha;
                return half4(half3(col * aF * o2), half(aF * o2));
            }
        """.trimIndent()
    }
}
