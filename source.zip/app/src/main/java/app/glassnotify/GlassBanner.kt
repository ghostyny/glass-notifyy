package app.glassnotify

import android.app.ActivityOptions
import android.app.Dialog
import android.app.PendingIntent
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import android.text.TextUtils
import android.util.TypedValue
import android.view.Choreographer
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Баннер уведомления. Анимация перенесена с сайта «Liquid Glass: капля» один в один:
 * одна пружина прогресса (k=150, ζ=0.76) ведёт положение, ширину, высоту и появление текста;
 * уход: k=260, ζ=0.95; прозрачность стекла гаснет пружиной (k=420) через 260 мс.
 * Окно статичное (ширина экрана, верхняя полоса), капля рисуется шейдером внутри него.
 */
object GlassBanner {

    private var cur: Run? = null

    fun show(
        ctx: Context,
        appName: String,
        title: String,
        text: String,
        icon: Drawable?,
        contentIntent: PendingIntent?,
        durationMs: Long
    ) {
        cur?.kill()
        cur = null
        try {
            val r = Run(ctx, appName, title, text, icon, contentIntent, durationMs) { done ->
                if (cur === done) cur = null
            }
            cur = r
            r.start()
        } catch (e: Exception) {
            Capture.paused = false
            Capture.schedulePause(Config.STOP_DELAY_MS)
            cur = null
        }
    }

    fun dismiss(animated: Boolean) {
        val r = cur ?: return
        if (animated) r.leave() else r.kill()
    }
}

private class Sp(var x: Float, var t: Float, var k: Float, r: Float) {
    var d = 2f * r * sqrt(k)
    var v = 0f

    fun tune(nk: Float, nr: Float) {
        k = nk
        d = 2f * nr * sqrt(nk)
    }

    fun step(dt: Float) {
        val n = max(1, ceil(dt * 240f).toInt())
        val h = dt / n
        for (i in 0 until n) {
            v += (-k * (x - t) - d * v) * h
            x += v * h
        }
    }
}

private class ClipFrame(context: Context) : FrameLayout(context) {
    private val rect = RectF()
    private val path = Path()
    private var rad = 0f

    fun setLens(l: Float, t: Float, r: Float, b: Float, radius: Float) {
        rect.set(l, t, r, b)
        rad = radius
        invalidate()
    }

    override fun dispatchDraw(canvas: Canvas) {
        val sc = canvas.save()
        path.reset()
        path.addRoundRect(rect, rad, rad, Path.Direction.CW)
        canvas.clipPath(path)
        super.dispatchDraw(canvas)
        canvas.restoreToCount(sc)
    }
}

private class Run(
    private val ctx: Context,
    private val appName: String,
    private val title: String,
    private val text: String,
    private val icon: Drawable?,
    private val contentIntent: PendingIntent?,
    private val holdMs: Long,
    private val onDone: (Run) -> Unit
) {
    private val themed = ContextThemeWrapper(ctx, R.style.Theme_GlassDialog)
    private val choreo = Choreographer.getInstance()
    private val cb = Choreographer.FrameCallback { t -> frame(t) }

    private var D = 1f
    private var W = 0f
    private var sw = 0f
    private var sh = 0f
    private var fw = 0f
    private var fh = 0f
    private var sy = 0f
    private var endY = 0f
    private var pillCx = 0f
    private var pillCy = 0f
    private var pillHw = 0f
    private var pillHh = 0f
    private var pillOn = 0f

    private val p = Sp(0f, 0f, 150f, 0.76f)
    private val a = Sp(100f, 100f, 260f, 1f)
    private var el = 0f
    private var ex = 0f
    private var out = false
    private var set = false
    private var wob = 0f
    private var held = false
    private var dragOff = 0f
    private var downY = 0f
    private var lastNs = 0L
    private var startNs = 0L
    private var dead = false

    private var lensL = 0f
    private var lensT = 0f
    private var lensR = 0f
    private var lensB = 0f

    private lateinit var dialog: Dialog
    private lateinit var glass: GlassView
    private lateinit var clip: ClipFrame
    private lateinit var card: LinearLayout

    fun start() {
        Capture.paused = true
        Capture.holdOn()
        val res = themed.resources
        D = res.displayMetrics.density
        W = res.displayMetrics.widthPixels.toFloat()
        sw = 30f * D
        sh = 30f * D
        fh = 68f * D
        fw = min(W - 20f * D, 520f * D)

        val sbId = res.getIdentifier("status_bar_height", "dimen", "android")
        val statusBar = if (sbId > 0) res.getDimensionPixelSize(sbId).toFloat() else 24f * D

        // «Остров» берём из выреза экрана. Нет выреза: форма без слияния, старт из центра у статус-бара.
        val rects = try {
            themed.getSystemService(WindowManager::class.java)
                .currentWindowMetrics.windowInsets.displayCutout?.boundingRects
        } catch (e: Exception) {
            null
        }
        val cut = rects?.filter { it.top == 0 && it.bottom < 120f * D }?.minByOrNull { it.top }
        if (cut != null) {
            pillCx = cut.exactCenterX()
            pillCy = cut.exactCenterY()
            pillHw = cut.width() / 2f + 3f * D
            pillHh = cut.height() / 2f + 3f * D
            pillOn = 1f
        } else {
            pillCx = W / 2f
            pillCy = statusBar / 2f
            pillHw = 46f * D
            pillHh = 13f * D
            pillOn = 0f
        }
        sy = pillCy - sh / 2f
        endY = pillCy + pillHh + 10f * D
        val areaH = endY + fh + 28f * D

        // Содержимое: размер фиксированный, окно (клип) его открывает.
        card = LinearLayout(themed).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((14 * D).toInt(), 0, (16 * D).toInt(), 0)
        }
        val iconView = ImageView(themed).apply {
            setImageDrawable(icon)
            scaleType = ImageView.ScaleType.CENTER_CROP
            layoutParams = LinearLayout.LayoutParams((44 * D).toInt(), (44 * D).toInt()).apply {
                marginEnd = (12 * D).toInt()
            }
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, 14f * D)
                }
            }
        }
        val texts = LinearLayout(themed).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        fun label(value: String, sp: Float, alpha: Float, bold: Boolean) = TextView(themed).apply {
            this.text = value
            setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
            setTextColor(Color.argb((alpha * 255).toInt(), 255, 255, 255))
            setShadowLayer(6f * D, 0f, 1f * D, 0x66000000)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        texts.addView(label(appName, 11f, 0.75f, false))
        texts.addView(label(title.ifBlank { appName }, 15f, 1f, true))
        if (text.isNotBlank()) texts.addView(label(text, 14f, 0.92f, false))
        card.addView(iconView)
        card.addView(texts)
        card.alpha = 0f

        glass = GlassView(themed)
        val bm = Capture.strip
        if (bm != null && bm.width == W.toInt() && bm.height >= areaH.toInt()) {
            glass.setTexture(bm)
        }

        clip = ClipFrame(themed)
        clip.addView(card, FrameLayout.LayoutParams(fw.toInt(), fh.toInt()))

        val root = FrameLayout(themed)
        root.addView(glass, FrameLayout.LayoutParams(-1, -1))
        root.addView(clip, FrameLayout.LayoutParams(-1, -1))
        root.setOnTouchListener { _, ev -> onTouch(ev) }

        dialog = Dialog(themed, R.style.Theme_GlassDialog)
        dialog.setCancelable(false)
        dialog.setCanceledOnTouchOutside(false)
        val win = dialog.window!!
        win.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        win.addFlags(
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        )
        win.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        win.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        win.setGravity(Gravity.TOP or Gravity.START)
        val lp = win.attributes
        lp.format = PixelFormat.TRANSLUCENT
        lp.width = W.toInt()
        lp.height = areaH.toInt()
        lp.x = 0
        lp.y = 0
        lp.layoutInDisplayCutoutMode =
            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        win.attributes = lp
        dialog.setContentView(root, ViewGroup.LayoutParams(-1, -1))
        dialog.show()
        choreo.postFrameCallback(cb)
    }

    fun leave() {
        if (out) return
        out = true
        ex = 0f
        p.t = 0f
        p.tune(260f, 0.95f)
        a.tune(420f, 1f)
    }

    private fun frame(nowNs: Long) {
        if (dead) return
        val dt = if (lastNs == 0L) 1f / 60f else ((nowNs - lastNs) / 1e9f).coerceIn(0.001f, 0.033f)
        lastNs = nowNs
        if (startNs == 0L) startNs = nowNs
        val ms = dt * 1000f

        if (!out) {
            if (!held) el += ms
            if (!set && el >= 60f) {
                set = true
                p.t = 1f
            }
            if (el > holdMs) leave()
        } else {
            ex += ms
            if (ex > 260f) a.t = 0f
            if (ex > 1100f) {
                finish()
                return
            }
        }
        p.step(dt)
        a.step(dt)
        if (!held) dragOff -= dragOff * min(1f, dt * 10f)

        val q = p.x
        val y = sy + (endY - sy) * q + dragOff
        val w = (sw + (fw - sw) * q).coerceIn(1f, W)
        val h = max(1f, sh + (fh - sh) * q)
        val cx = pillCx + (W / 2f - pillCx) * q.coerceIn(0f, 1f)
        val ca = ((q - 0.3f) / 0.5f).coerceIn(0f, 1f)
        val sp = abs(p.v) * (endY - sy) / D
        wob += (min(2f, sp / 220f) - wob) * min(1f, dt * 10f)

        glass.update(
            cx, y + h / 2f, w / 2f, h / 2f,
            pillCx, pillCy, pillHw, pillHh,
            (a.x / 100f).coerceIn(0f, 1f),
            (0.3f + sp / 1800f).coerceIn(0f, 1f),
            28f * D, D, wob * D,
            (nowNs - startNs) / 1e9f,
            pillOn
        )

        val e = ca * ca * (3f - 2f * ca)
        card.translationX = cx - fw / 2f
        card.translationY = y + h / 2f - fh / 2f
        card.alpha = e
        val s = 0.92f + 0.08f * e
        card.scaleX = s
        card.scaleY = s
        val blur = (1f - e) * 5f * D
        card.setRenderEffect(
            if (blur > 0.5f) RenderEffect.createBlurEffect(blur, blur, Shader.TileMode.CLAMP) else null
        )
        clip.setLens(cx - w / 2f, y, cx + w / 2f, y + h, min(28f * D, h / 2f))
        lensL = cx - w / 2f
        lensR = cx + w / 2f
        lensT = y
        lensB = y + h

        choreo.postFrameCallback(cb)
    }

    private fun onTouch(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (ev.x < lensL || ev.x > lensR || ev.y < lensT || ev.y > lensB) return false
                held = true
                downY = ev.rawY
                dragOff = 0f
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (!held) return false
                dragOff = min(0f, ev.rawY - downY)
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (!held) return false
                held = false
                val moved = ev.rawY - downY
                if (moved < -24f * D) {
                    leave()
                } else if (abs(moved) < 10f * D) {
                    contentIntent?.let { fire(it) }
                    leave()
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                held = false
                return true
            }
        }
        return false
    }

    private fun fire(pi: PendingIntent) {
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                val options = ActivityOptions.makeBasic()
                options.setPendingIntentBackgroundActivityStartMode(
                    ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED
                )
                pi.send(ctx, 0, null, null, null, null, options.toBundle())
            } else {
                pi.send()
            }
        } catch (e: Exception) {
            // интент мог быть отозван приложением-источником
        }
    }

    fun kill() = finish()

    private fun finish() {
        if (dead) return
        dead = true
        choreo.removeFrameCallback(cb)
        runCatching { dialog.dismiss() }
        Capture.paused = false
        Capture.schedulePause(Config.STOP_DELAY_MS)
        onDone(this)
    }
}
