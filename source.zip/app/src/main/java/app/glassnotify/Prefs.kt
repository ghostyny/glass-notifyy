package app.glassnotify

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    const val ENABLED = "enabled"
    const val HIDE_ORIGINAL = "hide_original"

    fun of(context: Context): SharedPreferences =
        context.getSharedPreferences("glass_notify", Context.MODE_PRIVATE)
}

fun Context.dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
